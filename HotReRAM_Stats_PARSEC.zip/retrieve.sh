
#!/bin/sh
for i in {0..63}
do
  grep -inr "system.ruby.l2_cntrl0.L2cache.totalGroupWriteBacks::$i " x264_HotReRAM_Periodic.txt | awk '{print $2}' > print$i.txt
done

paste print0.txt print1.txt > x264_WBCount2.txt
rm print0.txt
rm print1.txt

for k in {2..63}
do
  sum=$(($k + 1))
  paste x264_WBCount$k.txt print$k.txt > x264_WBCount$sum.txt
  rm x264_WBCount$k.txt
  rm print$k.txt
done


for i in {0..63}
do
  grep -inr "system.ruby.l2_cntrl0.L2cache.totalGroupreadSet::$i " x264_HotReRAM_Periodic.txt | awk '{print $2}' > print$i.txt
done

paste print0.txt print1.txt > x264_RDCount2.txt
rm print0.txt
rm print1.txt

for k in {2..63}
do
  sum=$(($k + 1))
  paste x264_RDCount$k.txt print$k.txt > x264_RDCount$sum.txt
  rm x264_RDCount$k.txt
  rm print$k.txt
done


for i in {0..63}
do
  grep -inr "system.ruby.l2_cntrl0.L2cache.totalGroupwriteAllocate::$i " x264_HotReRAM_Periodic.txt | awk '{print $2}' > print$i.txt
done

paste print0.txt print1.txt > x264_WRCount2.txt
rm print0.txt
rm print1.txt

for k in {2..63}
do
  sum=$(($k + 1))
  paste x264_WRCount$k.txt print$k.txt > x264_WRCount$sum.txt
  rm x264_WRCount$k.txt
  rm print$k.txt
done


